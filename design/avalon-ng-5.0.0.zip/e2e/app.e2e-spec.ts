import { AvalonPage } from './app.po';

describe('Avalon App', function() {
  let page: AvalonPage;

  beforeEach(() => {
    page = new AvalonPage();
  });

});
